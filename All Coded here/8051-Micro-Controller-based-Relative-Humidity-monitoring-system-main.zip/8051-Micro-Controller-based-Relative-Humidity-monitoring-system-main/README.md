# 8051-Micro-Controller-based-Relative-Humidity-monitoring-system
I have worked on Micro Controller based relative humidity monitoring system using DHT11 humidity sensor, Proteus Professional and 8051 Micro Controller which mainly focuses on reducing the loss of prawn, fish ponds production and maintenance ; sea sailor/fisher man protection.

# Circuit Diagram

![image](https://user-images.githubusercontent.com/73469122/126080762-296c117e-b9e7-4e8e-9e97-eaaf308d8128.png)

